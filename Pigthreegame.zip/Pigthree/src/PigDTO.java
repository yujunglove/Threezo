public abstract class PigDTO {
	
    public int hp = 100;  
	public int build = 0; 
	
	public abstract void home(); 
	public abstract void deco();

}
